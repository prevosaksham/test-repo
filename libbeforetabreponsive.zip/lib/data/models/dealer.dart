import 'package:equatable/equatable.dart';

/// One dealer from `POST /rm/getDealers` (`data[]`).
class Dealer extends Equatable {
  const Dealer({
    required this.id,
    required this.name,
    required this.city,
    required this.state,
  });

  final String id;
  final String name; // dealerName
  final String city;
  final String state;

  /// "Kiren Bajirrao, Nashik" — name plus a title-cased city to tell apart
  /// dealers that share a name.
  String get label {
    final c = city.trim();
    if (c.isEmpty) return name;
    final pretty =
        c[0].toUpperCase() + c.substring(1).toLowerCase();
    return '$name, $pretty';
  }

  factory Dealer.fromJson(Map<String, dynamic> json) {
    String s(dynamic v) => v == null ? '' : v.toString();
    return Dealer(
      id: s(json['id']),
      name: s(json['dealerName']),
      city: s(json['city']),
      state: s(json['state']),
    );
  }

  @override
  List<Object?> get props => [id, name, city, state];
}
