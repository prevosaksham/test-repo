import 'dart:convert';
import 'dart:typed_data';

/// One previously-uploaded document from `POST /application/details`
/// (`data.applicantDocs[]` / `data.coApplicantDocs[]`).
class UploadedDoc {
  const UploadedDoc({
    required this.documentCode,
    required this.fileName,
    required this.originalName,
    required this.mimeType,
    required this.dataUri,
  });

  final String documentCode; // AADHAAR_FRONT, PAN, CO_PAN, …
  final String fileName; // stored name (uuid.jpg)
  final String originalName; // user's original file name (kapilsir.jpg)
  final String mimeType; // image/jpeg, application/pdf, …
  final String dataUri; // "data:image/jpeg;base64,…" (may be empty/null)

  bool get isPdf => mimeType.toLowerCase().contains('pdf');

  /// Decoded image bytes from [dataUri] (base64). Null when there's no data or
  /// it can't be decoded.
  Uint8List? get bytes {
    if (dataUri.isEmpty) return null;
    final i = dataUri.indexOf('base64,');
    final b64 = i >= 0 ? dataUri.substring(i + 7) : dataUri;
    try {
      return base64Decode(b64.trim());
    } catch (_) {
      return null;
    }
  }

  factory UploadedDoc.fromJson(Map<String, dynamic> json) {
    String s(dynamic v) => v == null ? '' : v.toString();
    final fd = json['fileData'];
    final file = fd is Map ? Map<String, dynamic>.from(fd) : <String, dynamic>{};
    return UploadedDoc(
      documentCode: s(json['documentCode']),
      fileName: s(file['fileName']),
      originalName: s(file['originalName']),
      mimeType: s(file['mimeType']),
      dataUri: s(file['dataUri']),
    );
  }
}

/// The two document lists from the application-details response.
class ApplicationDocs {
  const ApplicationDocs({required this.applicant, required this.coApplicant});

  final List<UploadedDoc> applicant;
  final List<UploadedDoc> coApplicant;

  factory ApplicationDocs.fromDetails(Map<String, dynamic> json) {
    // Response: { data: { applicantDocs: [], coApplicantDocs: [] } }
    final data = json['data'];
    final d = data is Map ? Map<String, dynamic>.from(data) : json;
    List<UploadedDoc> parse(dynamic raw) => (raw is List ? raw : const [])
        .whereType<Map>()
        .map((e) => UploadedDoc.fromJson(Map<String, dynamic>.from(e)))
        .toList();
    return ApplicationDocs(
      applicant: parse(d['applicantDocs']),
      coApplicant: parse(d['coApplicantDocs']),
    );
  }
}
