import 'package:dio/dio.dart';
import '../../core/network/api_endpoints.dart';
import '../../core/network/api_response.dart';
import '../../core/network/dio_client.dart';

/// Wrapper around the paginated leads list (`POST /rm/list`).
class LeadApiService {
  LeadApiService({Dio? dio}) : _dio = dio ?? DioClient.instance.dio;

  final Dio _dio;

  Future<Map<String, dynamic>> list({
    required int page,
    required int limit,
    String search = '',
    String leadStatus = '', // '' = all; else the selected filter value
  }) async {
    final res = await _dio.post(ApiEndpoints.rmList, data: {
      'page_limit': limit.toString(),
      'page_number': page.toString(),
      'search': search,
      if (leadStatus.trim().isNotEmpty) 'leadStatus': leadStatus.trim(),
    });
    return unwrapResponse(res);
  }

  /// Lead status list for the filter (`GET /rm/rm-status`). Returns the raw
  /// response body ({ success, data: [...] }).
  Future<dynamic> rmStatus() async {
    final res = await _dio.get(ApiEndpoints.rmStatus);
    return res.data;
  }

  /// Resume/preview state for a single lead (`POST /rm/getPreview`).
  Future<Map<String, dynamic>> getPreview({required String leadId}) async {
    final res = await _dio.post(ApiEndpoints.rmGetPreview, data: {'leadId': leadId});
    return unwrapResponse(res);
  }

  /// Read-only details for the View screen (`POST /rm/lead-details`).
  Future<Map<String, dynamic>> leadDetails({required String leadId}) async {
    final res =
        await _dio.post(ApiEndpoints.rmLeadDetails, data: {'leadId': leadId});
    return unwrapResponse(res);
  }

  /// Record a call outcome / schedule a callback (`POST /rm/scheduleCall`).
  Future<Map<String, dynamic>> scheduleCall({
    required Map<String, dynamic> body,
  }) async {
    final res = await _dio.post(ApiEndpoints.rmScheduleCall, data: body);
    return unwrapResponse(res);
  }

  /// Schedule / record a dealer visit (`POST /rm/scheduleVisit`).
  Future<Map<String, dynamic>> scheduleVisit({
    required Map<String, dynamic> body,
  }) async { 
    final res = await _dio.post(ApiEndpoints.rmScheduleVisit, data: body);
    return unwrapResponse(res);
  }

  /// Complete the Start-Application lead stage (`POST /rm/lead/preview`).
  /// Body: { leadId, callId, visitId }.
  Future<Map<String, dynamic>> completeStartApplication({
    required Map<String, dynamic> body,
  }) async {
    final res =
        await _dio.post(ApiEndpoints.rmCompleteStartApplication, data: body);
    return unwrapResponse(res);
  }

  /// Dealers for a lead's OEM + city (`POST /rm/getDealers`).
  Future<Map<String, dynamic>> getDealers({
    required Object oemId,
    required String city,
  }) async {
    final res = await _dio.post(
      ApiEndpoints.rmGetDealers,
      data: {'oemId': oemId, 'city': city},
    );
    return unwrapResponse(res);
  }
}
