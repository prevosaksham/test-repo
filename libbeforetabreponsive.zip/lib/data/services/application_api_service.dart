import 'package:dio/dio.dart';
import '../../core/network/api_endpoints.dart';
import '../../core/network/dio_client.dart';

/// Multipart upload of KYC documents for the Upload Document stage
/// (`POST /application/upload-documents`). Uses the app's authenticated Dio
/// (Bearer token attached by the interceptor).
class ApplicationApiService {
  ApplicationApiService({Dio? dio}) : _dio = dio ?? DioClient.instance.dio;

  final Dio _dio;

  /// [filePaths] maps each API field name (e.g. AADHAAR_FRONT) to a local file
  /// path. Fields with a null/empty path are sent as an empty string (the
  /// backend expects every field present).
  Future<dynamic> uploadDocuments({
    required String leadId,
    required String stageId,
    required String stageType,
    required String status,
    required Map<String, String?> filePaths,
  }) async {
    final map = <String, dynamic>{
      'leadId': leadId,
      'stageId': stageId,
      'stageType': stageType,
      'status': status,
    };
    for (final entry in filePaths.entries) {
      final path = entry.value;
      if (path == null || path.isEmpty) {
        map[entry.key] = '';
      } else {
        map[entry.key] = await MultipartFile.fromFile(
          path,
          filename: path.split('/').last,
        );
      }
    }
    final res = await _dio.post(
      ApiEndpoints.applicationUploadDocuments,
      data: FormData.fromMap(map),
    );
    return res.data;
  }

  /// Per-document upload (`POST /application/upload`). Sends ONLY the given file
  /// field(s) + leadId — one single document, or one front+back pair. [files]
  /// maps each API field name (e.g. AADHAAR_FRONT) to a local file path.
  /// [files] maps each API field name to a local file path.
  Future<dynamic> uploadFiles({
    required String leadId,
    required Map<String, String> files,
    Map<String, String>? fields, // extra non-file form fields (e.g. proof_Type)
  }) async {
    final map = <String, dynamic>{'leadId': leadId};
    if (fields != null) map.addAll(fields);
    for (final entry in files.entries) {
      map[entry.key] = await MultipartFile.fromFile(
        entry.value,
        filename: entry.value.split('/').last,
      );
    }
    final res = await _dio.post(
      ApiEndpoints.applicationUpload,
      data: FormData.fromMap(map),
    );
    return res.data;
  }

  /// Consent/terms list shown on the consent screen (`POST /consent/list`,
  /// body { lang }). [lang] is the language code 'en' | 'hi' | 'mr'.
  Future<dynamic> consentList({String lang = 'en'}) async {
    final res = await _dio.post(ApiEndpoints.consentList, data: {'lang': lang});
    return res.data;
  }

  /// Send consent OTP to the applicant + co-applicant (`POST /consent/send-otp`).
  /// [consentIds] are the int ids of every consent item; [applicantTypes] is the
  /// [{ applicantType, mobileNumber }] list for the applicant + co-applicant.
  Future<dynamic> sendConsentOtp({
    required dynamic applicationId,
    required List<int> consentIds,
    required List<Map<String, dynamic>> applicantTypes,
  }) async {
    final res = await _dio.post(
      ApiEndpoints.consentSendOtp,
      data: {
        'applicationId': applicationId,
        'consentIds': consentIds,
        'applicantTypes': applicantTypes,
      },
    );
    return res.data;
  }

  /// Send the consent LINK to the applicant + co-applicant
  /// (`POST /consent/send-link`). Same body shape as send-otp.
  Future<dynamic> sendConsentLink({
    required dynamic applicationId,
    required List<int> consentIds,
    required List<Map<String, dynamic>> applicantTypes,
  }) async {
    final res = await _dio.post(
      ApiEndpoints.consentSendLink,
      data: {
        'applicationId': applicationId,
        'consentIds': consentIds,
        'applicantTypes': applicantTypes,
      },
    );
    return res.data;
  }

  /// Resend the OTP to a SINGLE applicant type (`POST /consent/resend-otp`).
  /// [applicantType] is "APPLICANT" or "CO_APPLICANT"; [mobileNumber] is that
  /// person's number (sent only when non-empty).
  Future<dynamic> resendConsentOtp({
    required dynamic applicationId,
    required List<int> consentIds,
    required String applicantType,
    String mobileNumber = '',
  }) async {
    final res = await _dio.post(
      ApiEndpoints.consentResendOtp,
      data: {
        'applicationId': applicationId,
        'consentIds': consentIds,
        'applicantType': applicantType,
        if (mobileNumber.trim().isNotEmpty) 'mobileNumber': mobileNumber.trim(),
      },
    );
    return res.data;
  }

  /// Resend the LINK to a SINGLE applicant type (`POST /consent/resend-link`).
  /// [applicantType] is "APPLICANT" or "CO_APPLICANT". Body shape mirrors
  /// resend-otp (minus the otp).
  Future<dynamic> resendConsentLink({
    required dynamic applicationId,
    required List<int> consentIds,
    required String applicantType,
  }) async {
    final res = await _dio.post(
      ApiEndpoints.consentResendLink,
      data: {
        'applicationId': applicationId,
        'consentIds': consentIds,
        'applicantType': applicantType,
      },
    );
    return res.data;
  }

  /// Verify the OTPs for the applicant + co-applicant in ONE call
  /// (`POST /consent/verify-otp`). [applicantTypes] is the
  /// [{ applicantType, otp }] list.
  Future<dynamic> verifyConsentOtp({
    required dynamic applicationId,
    required List<Map<String, dynamic>> applicantTypes,
  }) async {
    final res = await _dio.post(
      ApiEndpoints.consentVerifyOtp,
      data: {
        'applicationId': applicationId,
        'applicantTypes': applicantTypes,
      },
    );
    return res.data;
  }

  /// Full application details (`POST /application/details`, body { leadId }).
  /// Returns the parsed response; the caller reads `data.applicantDocs` /
  /// `data.coApplicantDocs` to re-show previously uploaded images.
  Future<dynamic> getDetails({required String leadId}) async {
    final res = await _dio.post(
      ApiEndpoints.applicationDetails,
      data: {'leadId': leadId},
    );
    return res.data;
  }

  /// Save applicant + co-applicant details (`POST /application/save-applicant`).
  /// [appData]/[coAppData] are the full person objects (from /details) with the
  /// user's edits merged in.
  Future<dynamic> saveApplicant({
    required Map<String, dynamic> appData,
    required Map<String, dynamic> coAppData,
    required dynamic stageId,
    required String stageType,
    required String status,
    required dynamic leadId,
    required String consentType, // "OTP" / "LINK" — outside app/coApp data
  }) async {
    final res = await _dio.post(
      ApiEndpoints.applicationSaveApplicant,
      data: {
        'appData': appData,
        'coAppData': coAppData,
        'stageId': stageId,
        'stageType': stageType,
        'status': status,
        'leadId': leadId,
        'consentType': consentType,
      },
    );
    return res.data;
  }

  /// Save the consent terms (`POST /application/save-term`) — on the OTP
  /// Verified screen's Proceed.
  Future<dynamic> saveTerm({
    required dynamic applicationId,
    required dynamic leadId,
    required dynamic stageId,
    required String stageType,
  }) async {
    final res = await _dio.post(
      ApiEndpoints.applicationSaveTerm,
      data: {
        'applicationId': applicationId,
        'leadId': leadId,
        'stageId': stageId,
        'stageType': stageType,
      },
    );
    return res.data;
  }

  /// Save KYC document verification (`POST /application/save-verification`) — on
  /// the KYC screen's Proceed. [docsVerifications] is the
  /// [{ applicantType, documentCode }] list.
  Future<dynamic> saveVerification({
    required dynamic applicationId,
    required dynamic leadId,
    required dynamic stageId,
    required String stageType,
    required List<Map<String, dynamic>> docsVerifications,
  }) async {
    final res = await _dio.post(
      ApiEndpoints.applicationSaveVerification,
      data: {
        'applicationId': applicationId,
        'leadId': leadId,
        'stageId': stageId,
        'stageType': stageType,
        'docsVerifications': docsVerifications,
      },
    );
    return res.data;
  }

  /// Final application submit (`POST /application/submit`) — on the Submit
  /// Application screen.
  Future<dynamic> submitApplication({
    required dynamic applicationId,
    required dynamic leadId,
    required dynamic stageId,
    required String stageType,
    required String status,
  }) async {
    final res = await _dio.post(
      ApiEndpoints.applicationSubmit,
      data: {
        'applicationId': applicationId,
        'leadId': leadId,
        'stageId': stageId,
        'stageType': stageType,
        'status': status,
      },
    );
    return res.data;
  }

  /// Bank account verification (`POST /bank-verification`). [idNumber] is the
  /// applicant's bank account number, [ifsc] the IFSC code (both from
  /// /application/details `bankDetails`). `ifsc_details` is always true.
  Future<dynamic> bankVerification({
    required String idNumber,
    required String ifsc,
  }) async {
    final res = await _dio.post(
      ApiEndpoints.bankVerification,
      data: {
        'id_number': idNumber,
        'ifsc': ifsc,
        'ifsc_details': true,
      },
    );
    return res.data;
  }

  /// House-ownership checksum (`POST /location/checksum`) — derives the
  /// Residence Type for the applicant + co-applicant from their names.
  /// [applicant]/[coApplicant] are the request objects (fullName, fatherName /
  /// relationshipStatus, maritalStatus, permanentAddressProofName).
  Future<dynamic> checkOwnership({
    required Map<String, dynamic> applicant,
    required Map<String, dynamic> coApplicant,
  }) async {
    final res = await _dio.post(
      ApiEndpoints.locationChecksum,
      data: {
        'applicant': applicant,
        'coApplicant': coApplicant,
      },
    );
    return res.data;
  }

  /// Delete an uploaded document (`POST /application/delete-document`,
  /// body { leadId, docCode }). docCode is the grouped code (AADHAAR, CO_PAN…).
  Future<dynamic> deleteDocument({
    required String leadId,
    required String docCode,
  }) async {
    final res = await _dio.post(
      ApiEndpoints.applicationDeleteDocument,
      data: {'leadId': leadId, 'docCode': docCode},
    );
    return res.data;
  }
}
