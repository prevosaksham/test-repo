import 'package:flutter/material.dart';
import '../../data/models/lead_item.dart';
import '../../data/models/person_detail.dart';
import '../../data/repositories/application_repository.dart';
import '../../routes/app_routes.dart';
import '../../theme/app_colors.dart';
import '../widgets/interaction_ui.dart';
import 'application_flow_ui.dart';
import 'kyc_verification_screen.dart';

/// Step 3 of 5 — final consent confirmation. Both flows converge here:
///  • OTP mode → from the "OTP Verified Successfully" screen's Proceed.
///  • Link mode → from the Consent Link Sent screen's Proceed.
/// Shows the applicant + co-applicant captured cards (real name/mobile fetched
/// from `/application/details`). Exit returns home; Proceed continues to KYC.
class ConsentCapturedSuccessScreen extends StatefulWidget {
  const ConsentCapturedSuccessScreen({
    super.key,
    required this.lead,
    this.applicationId = '',
    this.applicationNo = '',
    this.applicantMobile = '',
    this.coApplicantMobile = '',
  });
  final LeadItem lead;
  final String applicationId;
  final String applicationNo;
  final String applicantMobile; // edited number actually used in the flow
  final String coApplicantMobile;

  @override
  State<ConsentCapturedSuccessScreen> createState() =>
      _ConsentCapturedSuccessScreenState();
}

class _ConsentCapturedSuccessScreenState
    extends State<ConsentCapturedSuccessScreen> {
  final ApplicationRepository _repo = ApplicationRepository();
  ApplicationDetails? _details;
  bool _loading = true; // /application/details fetch in progress

  @override
  void initState() {
    super.initState();
    _load();
  }

  // Pull the applicant + co-applicant names from /details (mobiles come from the
  // flow, falling back to the API). Errors are ignored — the cards just show the
  // data we already have.
  Future<void> _load() async {
    try {
      final d = await _repo.getApplicationDetails(leadId: widget.lead.id);
      if (mounted) setState(() => _details = d);
    } catch (_) {
      /* keep whatever we already have */
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  String _appMobile() {
    if (widget.applicantMobile.trim().isNotEmpty) {
      return widget.applicantMobile.trim();
    }
    return _details?.applicant?.phoneNumber ?? '';
  }

  String _coMobile() {
    if (widget.coApplicantMobile.trim().isNotEmpty) {
      return widget.coApplicantMobile.trim();
    }
    return _details?.coApplicant?.phoneNumber ?? '';
  }

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    return AppFlowScaffold(
      title: 'Consent',
      stepText: 'Step 3 of 5',
      bottomBar: InteractionBottomBar(
        actionLabel: 'Proceed',
        enabled: !_loading,
        onAction: () => Navigator.of(context).push(MaterialPageRoute(
          builder: (_) => KycVerificationScreen(lead: widget.lead),
        )),
        onExit: () => Navigator.of(context)
            .pushNamedAndRemoveUntil(AppRoutes.home, (r) => false),
      ),
      // Loader until /application/details arrives, then the content.
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
        children: [
          const SizedBox(height: 8),
          const Center(child: SuccessBadge(bigCheck: true)),
          const SizedBox(height: 16),
          Center(
            child: Text('Consent Captured Successfully',
                style: TextStyle(
                    fontSize: 18, fontWeight: FontWeight.w700, color: p.title)),
          ),
          const SizedBox(height: 18),
          // Green confirmation banner.
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppColors.success.withValues(alpha: 0.10),
              borderRadius: BorderRadius.circular(12),
              border:
                  Border.all(color: AppColors.success.withValues(alpha: 0.30)),
            ),
            child: Row(
              children: [
                Container(
                  width: 26,
                  height: 26,
                  decoration: const BoxDecoration(
                      shape: BoxShape.circle, color: AppColors.success),
                  child: const Icon(Icons.check, size: 15, color: Colors.white),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'Applicant & Co-Applicant consent has been Captured '
                    'Successfully.',
                    style: TextStyle(fontSize: 13, height: 1.4, color: p.title),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          _personCard(
            nameLabel: 'Applicant Name:',
            name: _details?.applicant?.fullName ?? '',
            mobile: _appMobile(),
          ),
          const SizedBox(height: 14),
          _personCard(
            nameLabel: 'Co-Applicant Name:',
            name: _details?.coApplicant?.fullName ?? '',
            mobile: _coMobile(),
          ),
        ],
      ),
    );
  }

  Widget _personCard({
    required String nameLabel,
    required String name,
    required String mobile,
  }) {
    return FlowCard(
      child: Column(
        children: [
          DetailRow(label: nameLabel, value: name),
          DetailRow(
              label: 'Mobile Number:',
              value: mobile.isNotEmpty ? '+91 $mobile' : ''),
          const DetailRow(
            label: 'Status:',
            valueWidget: StatusPill(text: 'Consent Captured'),
          ),
        ],
      ),
    );
  }
}
