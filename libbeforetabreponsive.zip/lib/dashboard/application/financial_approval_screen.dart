import 'package:flutter/material.dart';
import '../../data/models/lead_item.dart';
import '../../theme/app_colors.dart';
import '../widgets/interaction_ui.dart';
import 'application_flow_ui.dart';

/// Financial Approval stage — "Loan Approval Pending" status. Proceed stays
/// disabled until the Credit Officer approves. Static placeholder.
class FinancialApprovalScreen extends StatelessWidget {
  const FinancialApprovalScreen({super.key, required this.lead});
  final LeadItem lead;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    return AppFlowScaffold(
      title: 'Financial Approval',
      bottomBar: InteractionBottomBar(
        actionLabel: 'Proceed',
        enabled: false, // awaiting approval
        onAction: () {},
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(24, 40, 24, 16),
        children: [
          Center(
            child: Container(
              width: 92,
              height: 92,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.purple.withValues(alpha: 0.10),
              ),
              child: Container(
                width: 52,
                height: 52,
                alignment: Alignment.center,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppColors.chartProgress,
                ),
                child: const Icon(Icons.priority_high,
                    size: 30, color: Colors.white),
              ),
            ),
          ),
          const SizedBox(height: 20),
          Center(
            child: Text(
              'Loan Approval Pending',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w700,
                color: p.title,
              ),
            ),
          ),
          const SizedBox(height: 10),
          Center(
            child: Text(
              'Awaiting Credit Officer Approval to proceed with Field '
              'Investigation',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 14, height: 1.5, color: p.subtitle),
            ),
          ),
        ],
      ),
    );
  }
}
