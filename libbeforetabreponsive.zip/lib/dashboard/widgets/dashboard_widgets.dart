import 'package:flutter/material.dart';
import '../../theme/app_colors.dart';

/// A rounded grey panel that wraps a titled section (Today Task, charts, …).
class SectionCard extends StatelessWidget {
  const SectionCard({super.key, required this.child, this.padding});
  final Widget child;
  final EdgeInsets? padding;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    return Container(
      width: double.infinity,
      padding: padding ?? const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: p.cardBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: p.fieldBorder),
      ),
      child: child,
    );
  }
}

/// One task row inside the Home "Today Task" card: Lead ID + Name header, a
/// divider, then label/value lines.
class TaskTile extends StatelessWidget {
  const TaskTile({
    super.key,
    required this.leadId,
    required this.leadName,
    required this.rows,
    this.alignValueToName = false,
  });
  final String leadId;
  final String leadName;
  final List<(String, String)> rows;
  // true → each row uses the SAME two-column split as the header, so the value
  // lines up exactly under "Lead Name" (label sits under "Lead ID"). false → the
  // classic label-on-left (fixed width), value-on-right layout.
  final bool alignValueToName;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: p.fieldBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: _kv('Lead ID', leadId,
                    valueColor: AppColors.purple, valueBold: true),
              ),
              Expanded(
                child: _kv('Lead Name', leadName,
                    valueColor: p.title, valueBold: true),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: Divider(height: 1, color: p.fieldBorder),
          ),
          for (final r in rows)
            if (alignValueToName)
              // Same two-column split as the header → value lines up under
              // "Lead Name", label under "Lead ID".
              Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Text(r.$1,
                          style: TextStyle(fontSize: 13, color: p.subtitle)),
                    ),
                    Expanded(
                      child: Text(r.$2,
                          style: TextStyle(
                              fontSize: 13,
                              color: p.title,
                              fontWeight: FontWeight.w600)),
                    ),
                  ],
                ),
              )
            else
              Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Wide enough for the longest label, kept to ONE line so the
                    // label never wraps vertically.
                    SizedBox(
                      width: 150,
                      child: Text(r.$1,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(fontSize: 13, color: p.subtitle)),
                    ),
                    Expanded(
                      child: Text(r.$2,
                          style: TextStyle(
                              fontSize: 13,
                              color: p.title,
                              fontWeight: FontWeight.w600)),
                    ),
                  ],
                ),
              ),
        ],
      ),
    );
  }

  Widget _kv(String label, String value,
      {required Color valueColor, bool valueBold = false}) {
    return Builder(builder: (context) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style: TextStyle(
                  fontSize: 12, color: context.palette.subtitle)),
          const SizedBox(height: 4),
          Text(value,
              style: TextStyle(
                  fontSize: 14,
                  color: valueColor,
                  fontWeight: valueBold ? FontWeight.w700 : FontWeight.w500)),
        ],
      );
    });
  }
}
