import 'package:flutter/material.dart';
import '../../data/models/lead_item.dart';
import '../application/application_flow_ui.dart';

/// Lead Details — read-only summary opened from the eye icon on a My Leads card.
/// Basic details come from the lead where available; the rest (DOB/Gender/full
/// address + Vehicle details) is static demo until those fields are in the API.
class LeadDetailsScreen extends StatelessWidget {
  const LeadDetailsScreen({super.key, required this.lead});
  final LeadItem lead;

  static const String _address =
      'Ram Apparment Block No 2, Chhota Tajbagh Chouk, Opp. Chandni Baar Road, '
      'Sakkardara, Nagpur, Maharashtra- 440024.';

  String _v(String s, [String fallback = '—']) => s.isEmpty ? fallback : s;

  @override
  Widget build(BuildContext context) {
    return AppFlowScaffold(
      title: 'Lead Details',
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
        children: [
          FlowCard(
            heading: 'Basic Details',
            child: Column(
              children: [
                DetailRow(label: 'Lead ID:', value: _v(lead.leadNo)),
                DetailRow(label: 'Lead Name:', value: _v(lead.name)),
                DetailRow(label: 'Mobile Number:', value: _v(lead.mobile)),
                DetailRow(label: 'Email Address:', value: _v(lead.email)),
                const DetailRow(label: 'Date of Birth:', value: '20/02/1990'),
                const DetailRow(label: 'Gender:', value: 'Female'),
                const DetailRow(label: 'Address:', value: _address),
              ],
            ),
          ),
          const SizedBox(height: 14),
          const FlowCard(
            heading: 'Vehicle Details',
            child: Column(
              children: [
                DetailRow(label: 'OEM:', value: 'Kinetic Green'),
                DetailRow(label: 'Dealer:', value: 'ABC Motors'),
                DetailRow(label: 'Vehicle Model:', value: 'Pink EV Super DX'),
                DetailRow(
                    label: 'Vehicle Category:',
                    value: 'Electric Three-Wheeler Passenger'),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
