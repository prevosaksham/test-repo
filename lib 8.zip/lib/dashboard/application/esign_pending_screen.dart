import 'package:flutter/material.dart';
import '../../core/device/app_device.dart';
import '../../data/models/financial_approval.dart';
import '../../data/models/lead_item.dart';
import '../../data/repositories/lead_repository.dart';
import '../../routes/app_routes.dart';
import '../../theme/app_colors.dart';
import 'application_flow_ui.dart';
import 'financial_documents_screen.dart';
import 'pre_disbursal_requirements_screen.dart';

/// eSign screen — pending/success driven by the details API's `esign.esigned`
/// (parsed into `allSigned`):
///   • false → "eSign Pending"  (Proceed enabled, awaiting signature)
///   • true  → "eSign Success"  (green, Date & Time, View Documents + Proceed)
/// The descriptive title/desc/date still come from `POST /field-verification/details`.
class ESignPendingScreen extends StatefulWidget {
  const ESignPendingScreen({super.key, required this.lead});
  final LeadItem lead;

  @override
  State<ESignPendingScreen> createState() => _ESignPendingScreenState();
}

class _ESignPendingScreenState extends State<ESignPendingScreen> {
  final _repo = LeadRepository();
  bool _loading = true;
  String? _error;
  FinancialApproval? _data;

  // Pending / success is driven by the details API's `esign.esigned`
  // (parsed into `allSigned`): false → "eSign Pending", true → "eSign Success".
  bool get _signed => _data?.allSigned ?? false;
  String get _title => _data?.esignTitle ?? '';
  String get _desc => _data?.esignDesc ?? '';
  String get _dateLabel => _fmtEsignDate(_data?.esignDate ?? '');

  static const _months = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', //
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
  ];

  // ISO datetime from the API → "20 May 2024, 11:42 AM" in the device's local
  // zone. Anything unparseable (e.g. an already-formatted string) is shown as-is.
  static String _fmtEsignDate(String v) {
    final s = v.trim();
    final dt = DateTime.tryParse(s)?.toLocal();
    if (dt == null) return s;
    final h12 = dt.hour % 12 == 0 ? 12 : dt.hour % 12;
    final minute = dt.minute.toString().padLeft(2, '0');
    final meridiem = dt.hour < 12 ? 'AM' : 'PM';
    return '${dt.day.toString().padLeft(2, '0')} ${_months[dt.month - 1]} '
        '${dt.year}, $h12:$minute $meridiem';
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final data = await _repo.getFinancialApproval(leadId: widget.lead.id);
      if (!mounted) return;
      setState(() {
        _data = data;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.toString().replaceFirst('ApiException: ', '');
        _loading = false;
      });
    }
  }

  // Proceed → Pre-Disbursal Requirements (enabled in both pending & success).
  void _proceed() => Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => PreDisbursalRequirementsScreen(lead: widget.lead),
        ),
      );

  void _viewDocuments() => Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => FinancialDocumentsScreen(lead: widget.lead),
        ),
      );

  // Exit clears the application stack and lands on Home, same as every other
  // screen in the flow.
  void _exit() => Navigator.of(context)
      .pushNamedAndRemoveUntil(AppRoutes.home, (r) => false);

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const AppFlowScaffold(
        title: 'eSign Pending',
        body: Center(child: CircularProgressIndicator()),
      );
    }
    if (_error != null) {
      return AppFlowScaffold(
        title: 'eSign Pending',
        body: _ErrorView(message: _error!, onRetry: _load),
      );
    }
    final signed = _signed;
    return AppFlowScaffold(
      title: signed ? 'eSign Success' : 'eSign Pending',
      bottomBar: signed
          // Success → View Document + (Exit | Proceed).
          ? _SuccessBar(
              onView: _viewDocuments, onProceed: _proceed, onExit: _exit)
          // Pending → Exit + Proceed DISABLED (awaiting signature).
          : _ProceedBar(enabled: false, onTap: _proceed, onExit: _exit),
      body: _StatusBody(
        signed: signed,
        title: _title,
        desc: _desc,
        dateLabel: _dateLabel,
      ),
    );
  }
}

/// Pending (amber) / signed (green) state — `signed` comes from the lead's
/// `esign.esigned`; title/desc come from the API (`esignStatus`); the Date & Time
/// card shows when signed.
class _StatusBody extends StatelessWidget {
  const _StatusBody({
    required this.signed,
    required this.title,
    required this.desc,
    required this.dateLabel,
  });
  final bool signed;
  final String title;
  final String desc;
  final String dateLabel;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    final titleText = title.isNotEmpty
        ? title
        : (signed
            ? 'Documents Signed Successfully!'
            : 'Documents yet to be signed');
    final descText = desc.isNotEmpty
        ? desc
        : (signed
            ? 'Your documents have been eSigned successfully.'
            : 'Your documents are pending signature.');
    return ListView(
      padding: const EdgeInsets.fromLTRB(24, 40, 24, 24),
      children: [
        Center(
          child: _Badge(
            inner: signed ? AppColors.success : AppColors.amber,
            icon: signed ? Icons.check : Icons.priority_high,
          ),
        ),
        const SizedBox(height: 22),
        Text(titleText,
            textAlign: TextAlign.center,
            style: TextStyle(
                fontSize: 21, fontWeight: FontWeight.w700, color: p.title)),
        const SizedBox(height: 10),
        Text(descText,
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 14, height: 1.4, color: p.subtitle)),
        if (signed && dateLabel.isNotEmpty) ...[
          const SizedBox(height: 24),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: p.cardBg,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: p.fieldBorder),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Date & Time:',
                    style: TextStyle(fontSize: 13, color: p.subtitle)),
                const SizedBox(height: 4),
                Text(dateLabel,
                    style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        color: p.title)),
              ],
            ),
          ),
        ],
      ],
    );
  }
}

/// Purple-tint circle with a filled inner badge (amber warning / green check).
class _Badge extends StatelessWidget {
  const _Badge({required this.inner, required this.icon});
  final Color inner;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 96,
      height: 96,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: AppColors.purple.withValues(alpha: 0.10),
      ),
      child: Container(
        width: 52,
        height: 52,
        alignment: Alignment.center,
        decoration: BoxDecoration(shape: BoxShape.circle, color: inner),
        child: Icon(icon, size: 30, color: Colors.white),
      ),
    );
  }
}

/// Pending bottom bar: outlined "Exit" (→ Home) over the gradient "Proceed"
/// button (dims while [enabled] is false).
class _ProceedBar extends StatelessWidget {
  const _ProceedBar({
    required this.enabled,
    required this.onTap,
    required this.onExit,
  });
  final bool enabled;
  final VoidCallback onTap;
  final VoidCallback onExit;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    return Container(
      padding: EdgeInsets.fromLTRB(16, 12, 16, 16 + AppDevice.bottomNavGap),
      decoration: BoxDecoration(
        color: p.surface,
        border: Border(top: BorderSide(color: p.fieldBorder)),
      ),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _GradientButton(
                label: 'Proceed', enabled: enabled, onTap: onTap),
            const SizedBox(height: 10),
            _ExitButton(onExit: onExit),
          ],
        ),
      ),
    );
  }
}

/// Success bottom bar: outlined "View Documents" + gradient "Proceed" +
/// outlined "Exit" (→ Home).
class _SuccessBar extends StatelessWidget {
  const _SuccessBar({
    required this.onView,
    required this.onProceed,
    required this.onExit,
  });
  final VoidCallback onView;
  final VoidCallback onProceed;
  final VoidCallback onExit;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    return Container(
      padding: EdgeInsets.fromLTRB(16, 12, 16, 16 + AppDevice.bottomNavGap),
      decoration: BoxDecoration(
        color: p.surface,
        border: Border(top: BorderSide(color: p.fieldBorder)),
      ),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            OutlinedButton(
              onPressed: onView,
              style: OutlinedButton.styleFrom(
                minimumSize: const Size.fromHeight(50),
                side: const BorderSide(color: AppColors.primary),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
              ),
              child: const Text('View Documents',
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      color: AppColors.primary)),
            ),
            const SizedBox(height: 10),
            _GradientButton(
                label: 'Proceed', enabled: true, onTap: onProceed),
            const SizedBox(height: 10),
            _ExitButton(onExit: onExit),
          ],
        ),
      ),
    );
  }
}

/// Outlined "Exit" button — always returns to Home (clears the application
/// stack), matching every other screen in the flow.
class _ExitButton extends StatelessWidget {
  const _ExitButton({required this.onExit});
  final VoidCallback onExit;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    return OutlinedButton(
      onPressed: onExit,
      style: OutlinedButton.styleFrom(
        minimumSize: const Size.fromHeight(50),
        side: BorderSide(color: p.fieldBorder),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
      child: Text('Exit',
          style: TextStyle(
              fontSize: 15, fontWeight: FontWeight.w700, color: p.title)),
    );
  }
}

class _GradientButton extends StatelessWidget {
  const _GradientButton({
    required this.label,
    required this.enabled,
    required this.onTap,
  });
  final String label;
  final bool enabled;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: enabled ? 1 : 0.5,
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: AppColors.buttonGradient,
          borderRadius: BorderRadius.circular(12),
        ),
        child: ElevatedButton(
          onPressed: enabled ? onTap : null,
          style: ElevatedButton.styleFrom(
            minimumSize: const Size.fromHeight(50),
            backgroundColor: Colors.transparent,
            shadowColor: Colors.transparent,
            disabledBackgroundColor: Colors.transparent,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12)),
          ),
          child: Text(label,
              style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: Colors.white)),
        ),
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  const _ErrorView({required this.message, required this.onRetry});
  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.error_outline, size: 40, color: p.subtitle),
            const SizedBox(height: 12),
            Text(message,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 14, color: p.subtitle)),
            const SizedBox(height: 14),
            OutlinedButton(
              onPressed: onRetry,
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: AppColors.primary),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10)),
              ),
              child: const Text('Retry',
                  style: TextStyle(color: AppColors.primary)),
            ),
          ],
        ),
      ),
    );
  }
}
