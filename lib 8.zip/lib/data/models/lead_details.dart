import 'lead_item.dart';
import 'person_detail.dart';
import 'uploaded_doc.dart';

/// One stage of the View screen's timeline (`data.timeline[]`). Carries only
/// what the API sends — name, description and the three status flags.
class LeadTimelineStage {
  const LeadTimelineStage({
    required this.id,
    required this.stageName,
    required this.desc,
    required this.actionAt,
    required this.completed,
    required this.current,
    required this.locked,
    required this.rejected,
    required this.completedByName,
  });

  final String id;
  final String stageName;
  final String desc; // details.desc — the action description
  final String actionAt; // details.actionAt — raw ISO timestamp (may be empty)
  final String completedByName; // details.completedBy.name (may be empty)
  final bool completed;
  final bool current;
  final bool locked;
  final bool rejected; // details.rejected — stage was rejected (shows a red ✕)

  // `rejected` wins over everything: a rejected stage is NEVER treated as
  // done/current/locked, so the other three flags are ignored when rejected.
  bool get isRejected => rejected;
  bool get isDone => !rejected && completed;
  bool get isCurrent => !rejected && !completed && current;
  bool get isLocked => !rejected && !completed && !current && locked;

  /// Short status label used on the pill (Rejected / Completed / In Progress /
  /// Locked / Pending).
  String get statusLabel {
    if (isRejected) return 'Rejected';
    if (isDone) return 'Completed';
    if (isCurrent) return 'In Progress';
    if (isLocked) return 'Locked';
    return 'Pending';
  }

  factory LeadTimelineStage.fromJson(Map<String, dynamic> j) {
    String s(dynamic v) => v == null ? '' : v.toString();
    // The action info is nested under `details` (null until the stage happens):
    // { desc, actionAt }. Fall back to a top-level `desc` for older responses.
    final det = j['details'] is Map
        ? Map<String, dynamic>.from(j['details'] as Map)
        : const <String, dynamic>{};
    // details.completedBy = { id, name } (null until the stage is actioned).
    final completedBy = det['completedBy'] is Map
        ? Map<String, dynamic>.from(det['completedBy'] as Map)
        : const <String, dynamic>{};
    return LeadTimelineStage(
      id: s(j['id']),
      stageName: s(j['stageName']),
      desc: s(det['desc'] ?? j['desc']),
      actionAt: s(det['actionAt']),
      completedByName: s(completedBy['name']),
      completed: j['completed'] == true,
      current: j['current'] == true,
      locked: j['locked'] == true,
      // `rejected` may sit on the stage root or inside `details`.
      rejected: j['rejected'] == true || det['rejected'] == true,
    );
  }
}

/// Full read-only payload behind the My Leads → "View" screen
/// (`POST /rm/lead-details` → `data`).
class LeadDetails {
  const LeadDetails({
    required this.name,
    required this.mobile,
    required this.location,
    required this.leadStatus,
    required this.currentStatus,
    required this.applicationId,
    required this.applicationNo,
    required this.applicationStatus,
    required this.timeline,
    required this.applicant,
    required this.coApplicant,
    required this.applicantDocs,
    required this.coApplicantDocs,
    this.bankDetails,
  });

  // Header (data.lead + data.application).
  final String name;
  final String mobile;
  final String location;
  final LeadStatusInfo leadStatus;
  final String currentStatus; // data.lead.currentStatus (e.g. "IN_PROGRESS")
  final String applicationId; // data.application.id
  final String applicationNo; // data.application.applicationNo (may be empty)
  final String applicationStatus; // data.application.status (e.g. "draft")

  final List<LeadTimelineStage> timeline;

  // Application Details (data.applicationDetails).
  final PersonDetail? applicant;
  final PersonDetail? coApplicant;
  final List<UploadedDoc> applicantDocs;
  final List<UploadedDoc> coApplicantDocs;
  // Applicant's bank details (data.bankDetails) — shown on the Applicant tab.
  final BankDetails? bankDetails;

  /// Lead's current status nicely cased for display ("IN_PROGRESS" →
  /// "In Progress").
  String get currentStatusLabel {
    final s = currentStatus.replaceAll('_', ' ').trim();
    if (s.isEmpty) return '';
    return s
        .split(RegExp(r'\s+'))
        .map((w) => w.isEmpty ? w : w[0].toUpperCase() + w.substring(1).toLowerCase())
        .join(' ');
  }

  /// Application status nicely cased for display ("draft" → "Draft").
  String get applicationStatusLabel {
    final s = applicationStatus.replaceAll('_', ' ').trim();
    if (s.isEmpty) return '';
    return s
        .split(RegExp(r'\s+'))
        .map((w) => w.isEmpty ? w : w[0].toUpperCase() + w.substring(1))
        .join(' ');
  }

  factory LeadDetails.fromResponse(Map<String, dynamic> json) {
    String s(dynamic v) => v == null ? '' : v.toString();

    final data = json['data'] is Map
        ? Map<String, dynamic>.from(json['data'] as Map)
        : json;

    final lead = data['lead'] is Map
        ? Map<String, dynamic>.from(data['lead'] as Map)
        : <String, dynamic>{};
    final app = data['application'] is Map
        ? Map<String, dynamic>.from(data['application'] as Map)
        : <String, dynamic>{};
    final ad = data['applicationDetails'] is Map
        ? Map<String, dynamic>.from(data['applicationDetails'] as Map)
        : <String, dynamic>{};

    final leadStatus = lead['leadStatus'] is Map
        ? LeadStatusInfo.fromJson(Map<String, dynamic>.from(lead['leadStatus']))
        : LeadStatusInfo.empty;

    final timeline = (data['timeline'] is List ? data['timeline'] as List : const [])
        .whereType<Map>()
        .map((e) => LeadTimelineStage.fromJson(Map<String, dynamic>.from(e)))
        .toList();

    PersonDetail? person(dynamic raw) {
      if (raw is Map) {
        return PersonDetail.fromJson(Map<String, dynamic>.from(raw));
      }
      if (raw is List && raw.isNotEmpty && raw.first is Map) {
        return PersonDetail.fromJson(Map<String, dynamic>.from(raw.first));
      }
      return null;
    }

    List<UploadedDoc> docs(dynamic raw) => (raw is List ? raw : const [])
        .whereType<Map>()
        .map((e) => UploadedDoc.fromJson(Map<String, dynamic>.from(e)))
        .toList();

    BankDetails? bank(dynamic raw) {
      if (raw is Map) return BankDetails.fromJson(Map<String, dynamic>.from(raw));
      if (raw is List && raw.isNotEmpty && raw.first is Map) {
        return BankDetails.fromJson(Map<String, dynamic>.from(raw.first));
      }
      return null;
    }

    return LeadDetails(
      name: s(lead['name']),
      mobile: s(lead['mobile']),
      location: s(lead['location']),
      leadStatus: leadStatus,
      currentStatus: s(lead['currentStatus']),
      applicationId: s(app['id']),
      applicationNo: s(app['applicationNo']),
      applicationStatus: s(app['status']),
      timeline: timeline,
      // Applicant / co-applicant + their docs may sit under `applicationDetails`
      // OR directly under `data` (depending on the endpoint shape) — accept both,
      // and tolerate the singular `coApplicant` key too.
      applicant: person(ad['applicant'] ?? data['applicant']),
      coApplicant: person(ad['coApplicants'] ??
          data['coApplicants'] ??
          ad['coApplicant'] ??
          data['coApplicant']),
      // Docs may be keyed `applicantDocuments`/`coApplicantDocuments` or the
      // shorter `applicantDocs`/`coApplicantDocs`, under `applicationDetails`
      // or directly under `data`.
      applicantDocs: docs(ad['applicantDocuments'] ??
          data['applicantDocuments'] ??
          ad['applicantDocs'] ??
          data['applicantDocs']),
      coApplicantDocs: docs(ad['coApplicantDocuments'] ??
          data['coApplicantDocuments'] ??
          ad['coApplicantDocs'] ??
          data['coApplicantDocs']),
      // bankDetails may sit under applicationDetails or directly under data.
      bankDetails: bank(ad['bankDetails'] ?? data['bankDetails']),
    );
  }
}
